# PARTYBAE — Digital Chaos System

The official hyperpop artist website for **PARTYBAE**. Built with Next.js 15, React 19, Tailwind CSS v4, and Motion.

## 🎵 Features

- **Complete SoundCloud Catalog** — All 16 verified tracks with official embed players
- **Live Sync Ready** — Optional automatic catalog updates via SoundCloud API
- **Immersive Hero** — Animated "PARTYBAE" wordmark with chromatic glitch, equalizer, parallax orbs
- **Music Section** — Featured/Now Playing panel, sortable discography grid, full profile embed
- **About** — First-person biography with kinetic typography, identity spec sheet, real SoundCloud avatar
- **PlayStation** — Holographic PSN identity card with 3D tilt, PS button colors, copy-to-clipboard
- **Connect** — Verified SoundCloud link, PSN copy, extensible social link system
- **Custom Cursor** — Desktop-only magnetic cursor with hover states
- **Preloader** — One-time boot sequence with progress, session persistence
- **Background FX** — Aurora blobs, particle field, scroll-reactive hue shift, noise overlay
- **Player Dock** — Floating playback controller (binds to SoundCloud Widget API)
- **Accessible** — Semantic HTML, focus states, reduced motion support, ARIA labels

## 🚀 Quick Start

```bash
cd partybae
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000)

## 🔧 Environment Variables

Copy `.env.example` to `.env.local`:

```bash
cp .env.example .env.local
```

| Variable | Required | Description |
|----------|----------|-------------|
| `SC_CLIENT_ID` | No | SoundCloud API client ID for live catalog sync. Register an app at [soundcloud.com/you/apps](https://soundcloud.com/you/apps). Without this, the site uses the committed verified snapshot (16 tracks as of Oct 28, 2026). |
| `NEXT_PUBLIC_SITE_URL` | No | Production URL for SEO/Open Graph. Defaults to `https://partybae.vercel.app`. |

## 📦 Catalog Verification & Sync

### Verified Snapshot (Committed)

The file `src/data/tracks.ts` contains the **verified catalog snapshot** from SoundCloud API as of **2026-10-28**:

- 16 public tracks confirmed via `api-v2.soundcloud.com/users/643183869/tracks`
- Each track includes: title, permalink, artwork (500×500), release date, duration, genre, description
- This snapshot is the **default** — site works with zero configuration

### Live Sync (Optional)

Set `SC_CLIENT_ID` in your environment to enable automatic catalog updates:

1. Register a SoundCloud app at https://soundcloud.com/you/apps
2. Copy the **Client ID** to `.env.local` as `SC_CLIENT_ID`
3. The site will fetch the live catalog on each ISR revalidate (hourly)

**Sync script** — Regenerate the committed snapshot:

```bash
SC_CLIENT_ID=your_client_id npm run sync:soundcloud
```

This overwrites `src/data/tracks.ts` with fresh data and updates `CATALOG_META.verifiedAt`.

### What's Verified vs What Needs Connection

| Data | Status | Source |
|------|--------|--------|
| Track list (16 tracks) | ✅ Verified | SoundCloud API |
| Track artwork | ✅ Verified | SoundCloud API (upgraded to 500×500) |
| Track metadata (date, duration, genre) | ✅ Verified | SoundCloud API |
| SoundCloud embed players | ✅ Working | Official oEmbed/Widget API |
| Profile embed (full catalog) | ✅ Working | Official Widget API |
| PlayStation ID | ✅ Verified | User-provided |
| Artist bio/identity | ✅ Verified | User-provided |
| Live auto-sync | ⚙️ Optional | Requires `SC_CLIENT_ID` |

**Note:** Genre from SoundCloud API returns "Hip-hop & Rap" for all tracks (artist-set field). The site brands PARTYBAE as **HYPERPOP** per artist identity; SoundCloud genre is displayed transparently in the featured panel.

## 🏗️ Project Structure

```
partybae/
├── public/
│   ├── icon.svg           # Waveform favicon
│   └── manifest.json      # PWA manifest
├── scripts/
│   └── sync-soundcloud.mjs  # Catalog sync script
├── src/
│   ├── app/
│   │   ├── globals.css    # Tailwind v4 theme, utilities, animations
│   │   ├── layout.tsx     # Root layout, fonts, metadata
│   │   ├── page.tsx       # Server component, fetches catalog
│   │   └── opengraph-image.tsx  # Dynamic OG image
│   ├── components/
│   │   ├── ui/            # GlitchText, Magnetic, Equalizer
│   │   ├── background-fx.tsx
│   │   ├── cursor.tsx
│   │   ├── preloader.tsx
│   │   ├── nav.tsx
│   │   ├── hero.tsx
│   │   ├── marquee.tsx
│   │   ├── section-heading.tsx
│   │   ├── music.tsx
│   │   ├── track-card.tsx
│   │   ├── player-dock.tsx
│   │   ├── about.tsx
│   │   ├── playstation.tsx
│   │   ├── connect.tsx
│   │   ├── footer.tsx
│   │   └── site-shell.tsx
│   ├── data/
│   │   ├── site.ts        # All site constants, config
│   │   └── tracks.ts      # Generated track catalog (commit this)
│   ├── lib/
│   │   ├── soundcloud.ts  # API, embed URLs, catalog fetching
│   │   ├── player-store.ts  # Cross-component player state
│   │   └── utils.ts
│   └── types/
│       └── soundcloud-widget.d.ts
├── package.json
├── next.config.ts
├── tsconfig.json
├── postcss.config.mjs
└── .env.example
```

## 🎨 Design System

### Colors (Tailwind v4 `@theme` tokens)

| Token | Hex | Use |
|-------|-----|-----|
| `--color-void` | `#05010a` | Page background |
| `--color-abyss` | `#0a0512` | Alt sections |
| `--color-panel` | `#0d0716` | Cards, panels |
| `--color-pulse` | `#a855f7` | Electric purple |
| `--color-bae` | `#ff2d9b` | Neon pink |
| `--color-acid` | `#c8ff2e` | Acid green |
| `--color-chrome` | `#d8d9e8` | Chrome silver |
| `--color-mist` | `#9d9ab4` | Muted text |

### Fonts (via `next/font/google`)

| Variable | Font | Weights |
|----------|------|---------|
| `--font-unbounded` | Unbounded | 400, 500, 700, 800 |
| `--font-grotesk` | Space Grotesk | 300–700 |
| `--font-jbmono` | JetBrains Mono | 400, 500, 700 |

### Key Utilities

- `.text-chrome` — Metallic gradient text
- `.text-plasma` — Purple→Pink→Acid gradient
- `.text-outline` — Outlined text (webkit-stroke)
- `.glass-panel` — Frosted glass card
- `.hud-corner*` — HUD corner brackets
- `.noise-overlay` — Subtle film grain
- `.eq-bar` — Animated equalizer bar

## 🌐 Deployment

### Vercel (Recommended)

1. Push to GitHub
2. Import in Vercel
3. Add Environment Variables:
   - `SC_CLIENT_ID` (optional, for live sync)
   - `NEXT_PUBLIC_SITE_URL` (your production domain)
4. Deploy

### Other Platforms

```bash
npm run build
npm run start
```

Output: `.next/` — deploy as Node.js server or static export (configure `next.config.ts` for `output: 'export'` if needed).

## ♿ Accessibility

- Semantic HTML5 landmarks (`header`, `nav`, `main`, `section`, `footer`)
- Single `<h1>` on hero, hierarchical headings
- Focus-visible outlines (acid color, 3px offset)
- ARIA labels on icon-only buttons
- `prefers-reduced-motion` respected (disables all animations)
- No unexpected autoplay (SoundCloud embeds require user gesture)
- Keyboard navigable custom cursor (disabled when not `pointer: fine`)
- Sufficient contrast ratios (WCAG AA)

## ⚡ Performance

- Next.js 15 App Router with Server Components
- ISR revalidation (1 hour) for catalog freshness
- `next/image` for optimized artwork (AVIF/WebP, lazy loading)
- Motion animations GPU-accelerated (transform/opacity)
- Particle canvas pauses on `document.hidden`
- SoundCloud Widget API loaded lazy (`strategy="lazyOnload"`)
- Bundle analysis: `npm run build` → check `.next/analyze`

## 📝 Credits

- **Artist**: PARTYBAE (soundcloud.com/partybae)
- **PlayStation**: TOKYO-_-OCCULT
- **Fonts**: Unbounded, Space Grotesk, JetBrains Mono (Google Fonts)
- **Icons**: Lucide React
- **Animations**: Motion (Framer Motion v12)
- **SoundCloud**: Official oEmbed & Widget API
- **Design Inspiration**: Y2K cyberpunk, hyperpop visual culture, experimental editorial design

## 📄 License

Private project for PARTYBAE. All rights reserved.