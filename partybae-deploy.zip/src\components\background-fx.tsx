'use client';

import { useEffect, useRef } from 'react';
import { useReducedMotion, useScroll, useTransform, motion } from 'motion/react';

export function BackgroundFX() {
  const reduced = useReducedMotion();
  const { scrollYProgress } = useScroll();
  const hue = useTransform(scrollYProgress, [0, 1], [0, 80]);

  useEffect(() => {
    if (reduced) return;
    const canvas = document.createElement('canvas');
    canvas.style.cssText = 'position:fixed;inset:0;z-index:0;pointer-events:none;opacity:0.4';
    document.body.appendChild(canvas);

    const ctx = canvas.getContext('2d')!;
    let raf: number;
    const particles: Array<{ x: number; y: number; vx: number; vy: number; size: number; hue: number; alpha: number }> = [];

    function resize() {
      canvas.width = window.innerWidth * devicePixelRatio;
      canvas.height = window.innerHeight * devicePixelRatio;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
    }
    resize();
    window.addEventListener('resize', resize);

    const count = Math.min(80, Math.floor((canvas.width * canvas.height) / 120000));
    for (let i = 0; i < count; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.3,
        vy: -0.15 - Math.random() * 0.35,
        size: 0.5 + Math.random() * 1.5,
        hue: Math.random() < 0.02 ? 100 : (Math.random() < 0.5 ? 280 : 330),
        alpha: 0.15 + Math.random() * 0.35,
      });
    }

    let lastScrollY = window.scrollY;
    function loop() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const scrollDelta = window.scrollY - lastScrollY;
      lastScrollY = window.scrollY;
      const boost = Math.min(Math.abs(scrollDelta) * 0.02, 2);

      for (const p of particles) {
        p.y += p.vy - (scrollDelta > 0 ? boost : 0);
        p.x += p.vx;
        if (p.y < -10) {
          p.y = canvas.height + 10;
          p.x = Math.random() * canvas.width;
        }
        if (p.x < -10) p.x = canvas.width + 10;
        if (p.x > canvas.width + 10) p.x = -10;

        const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * devicePixelRatio * 3);
        gradient.addColorStop(0, `hsla(${p.hue}, 90%, 65%, ${p.alpha})`);
        gradient.addColorStop(1, `hsla(${p.hue}, 90%, 65%, 0)`);
        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size * devicePixelRatio * 3, 0, Math.PI * 2);
        ctx.fill();
      }
      raf = requestAnimationFrame(loop);
    }
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      canvas.remove();
    };
  }, [reduced]);

  return (
    <>
      <motion.div
        aria-hidden="true"
        className="fixed inset-0 -z-10"
        style={{
          background: `
            radial-gradient(ellipse 70% 50% at 15% 15%, rgba(168, 85, 247, 0.15) 0%, transparent 60%),
            radial-gradient(ellipse 60% 45% at 85% 85%, rgba(255, 45, 155, 0.1) 0%, transparent 55%),
            radial-gradient(ellipse 50% 40% at 50% 50%, rgba(200, 255, 46, 0.04) 0%, transparent 50%)
          `,
        }}
      />
      <motion.div
        aria-hidden="true"
        className="fixed inset-0 -z-10"
        style={{
          filter: `hue-rotate(${hue}deg)`,
          background: `
            radial-gradient(ellipse 50% 35% at 30% 20%, rgba(168, 85, 247, 0.18) 0%, transparent 55%),
            radial-gradient(ellipse 40% 30% at 70% 80%, rgba(255, 45, 155, 0.12) 0%, transparent 50%)
          `,
        }}
      />
      <motion.div
        aria-hidden="true"
        className="fixed inset-0 -z-10"
        animate={{ rotate: [0, 360] }}
        transition={{ duration: 120, repeat: Infinity, ease: 'linear' }}
        style={{
          background: `
            radial-gradient(circle at 20% 30%, rgba(168, 85, 247, 0.08) 0%, transparent 40%),
            radial-gradient(circle at 80% 70%, rgba(255, 45, 155, 0.06) 0%, transparent 35%)
          `,
        }}
      />
    </>
  );
}