import { TRACKS, CATALOG_META, type Track } from '@/data/tracks';

export type { Track };
export type CatalogSource = 'live' | 'snapshot';

export interface CatalogResult {
  tracks: Track[];
  source: CatalogSource;
  fetchedAt: string;
}

export const SC_PROFILE_URL = 'https://soundcloud.com/partybae';
export const SC_USER_ID = 643183869;
const API_BASE = 'https://api-v2.soundcloud.com';

export function trackEmbedUrl(track: Track, opts?: { visual?: boolean; autoplay?: boolean; color?: string }): string {
  const params = new URLSearchParams({
    url: track.url,
    color: opts?.color ?? '#ff2d9b',
    auto_play: String(opts?.autoplay ?? false),
    hide_related: 'true',
    show_comments: 'false',
    show_user: 'true',
    show_reposts: 'false',
    visual: String(opts?.visual ?? false),
  });
  return `https://w.soundcloud.com/player/?${params.toString()}`;
}

export function profileEmbedUrl(visual = false): string {
  const params = new URLSearchParams({
    url: `https://api.soundcloud.com/users/${SC_USER_ID}`,
    color: '#ff2d9b',
    auto_play: 'false',
    hide_related: 'true',
    show_comments: 'false',
    show_user: 'true',
    show_reposts: 'false',
    visual: String(visual),
  });
  return `https://w.soundcloud.com/player/?${params.toString()}`;
}

async function fetchLive(): Promise<Track[] | null> {
  const cid = process.env.SC_CLIENT_ID;
  if (!cid) return null;

  const all: Track[] = [];
  let nextUrl: string | null = `${API_BASE}/users/${SC_USER_ID}/tracks?client_id=${cid}&limit=100&offset=0`;
  let pages = 0;
  const MAX_PAGES = 5;

  while (nextUrl && pages < MAX_PAGES) {
    try {
      const ctrl = new AbortController();
      const timeout = setTimeout(() => ctrl.abort(), 6000);
      const res: Response = await fetch(nextUrl, {
        headers: { accept: 'application/json' },
        signal: ctrl.signal,
        next: { revalidate: 3600 },
      });
      clearTimeout(timeout);

      if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);

      const data = await res.json();
      const tracks = data.collection ?? [];

      for (const t of tracks) {
        all.push({
          id: t.id,
          title: t.title,
          permalink: t.permalink,
          url: `https://soundcloud.com/partybae/${t.permalink}`,
          createdAt: t.created_at,
          durationMs: t.duration ?? 0,
          artwork: t.artwork_url
            ? t.artwork_url.replace(/-large\.(jpg|png)$/i, '-t500x500.$1').replace(/-t\d+x\d+\.(jpg|png)$/i, '-t500x500.$1')
            : t.user?.avatar_url
              ? t.user.avatar_url.replace(/-large\.(jpg|png)$/i, '-t500x500.$1')
              : null,
          genre: t.genre ?? null,
          description: (t.description ?? '').trim(),
        });
      }

      nextUrl = data.next_href ? `${data.next_href}&client_id=${cid}` : null;
      pages++;
      if (!nextUrl) break;
    } catch {
      return null;
    }
  }

  return all.length > 0 ? all : null;
}

export async function getCatalog(): Promise<CatalogResult> {
  const live = await fetchLive();
  if (live && live.length > 0) {
    return { tracks: live, source: 'live', fetchedAt: new Date().toISOString() };
  }
  return { tracks: TRACKS, source: 'snapshot', fetchedAt: CATALOG_META.verifiedAt };
}