'use client';

import { useEffect, useState } from 'react';
import { motion } from 'motion/react';

export function CustomCursor() {
  const [enabled, setEnabled] = useState(false);
  const [visible, setVisible] = useState(false);
  const [hovering, setHovering] = useState(false);
  const [pressed, setPressed] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const prefersFine = window.matchMedia('(pointer: fine)').matches;
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!prefersFine || reducedMotion) return;

    document.documentElement.classList.add('has-custom-cursor');
    setEnabled(true);

    const onMove = (e: MouseEvent) => {
      setVisible(true);
      const target = e.target as HTMLElement;
      setHovering(!!target.closest('a, button, [data-cursor-hover], .magnetic'));
    };

    const onMouseDown = () => setPressed(true);
    const onMouseUp = () => setPressed(false);
    const onLeave = () => setVisible(false);
    const onEnter = () => setVisible(true);

    window.addEventListener('mousemove', onMove);
    window.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mouseup', onMouseUp);
    document.addEventListener('mouseleave', onLeave);
    document.addEventListener('mouseenter', onEnter);

    return () => {
      document.documentElement.classList.remove('has-custom-cursor');
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mouseup', onMouseUp);
      document.removeEventListener('mouseleave', onLeave);
      document.removeEventListener('mouseenter', onEnter);
    };
  }, []);

  if (!enabled) return null;

  return (
    <>
      <motion.div
        aria-hidden="true"
        className="fixed top-0 left-0 z-[100] pointer-events-none mix-blend-difference"
        style={{ x: 0, y: 0 }}
        animate={{ x: 0, y: 0 }}
      >
        <div className="-translate-x-1/2 -translate-y-1/2 h-1.5 w-1.5 rounded-full bg-acid" />
      </motion.div>
      <motion.div
        aria-hidden="true"
        className="fixed top-0 left-0 z-[99] pointer-events-none transition-opacity duration-200"
        style={{ opacity: visible ? 1 : 0 }}
        animate={{ scale: hovering ? 2.2 : 1, borderColor: hovering ? 'rgba(255, 45, 155, 0.8)' : 'rgba(216, 217, 232, 0.4)' }}
      >
        <div className="-translate-x-1/2 -translate-y-1/2 h-8 w-8 rounded-full border border-chrome/40" />
      </motion.div>
      <style jsx global>{`
        .has-custom-cursor * {
          cursor: none !important;
        }
        .has-custom-cursor input,
        .has-custom-cursor textarea,
        .has-custom-cursor select {
          cursor: text !important;
        }
      `}</style>
    </>
  );
}